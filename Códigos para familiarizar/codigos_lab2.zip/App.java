public class App {
    public static void main(String[] args) throws Exception {
        // Create a random Person

        // Create a Computer programmer

        // Create a Web developer
       
        // Run tests
        Tests.testPerson();
        Tests.testCompProg();
        Tests.testWebDev();
    }
}
